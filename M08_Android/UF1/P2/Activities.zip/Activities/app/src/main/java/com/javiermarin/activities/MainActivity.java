package com.javiermarin.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.javiermarin.activities.author.AuthorActivity;
import com.javiermarin.activities.lords.LordsMainActivity;
import com.javiermarin.activities.name_age.NameAgeMainActivity;
import com.javiermarin.activities.password.PasswordMainActivity;

public class MainActivity extends AppCompatActivity {

    private Button openAuthor;
    private Button openPassword;
    private Button openLords;
    private Button openNameAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        openAuthor = findViewById(R.id.openAuthor);
        openAuthor.setOnClickListener(v -> showAuthor());

        openPassword = findViewById(R.id.openPassword);
        openPassword.setOnClickListener(v -> showPassword());

        openLords = findViewById(R.id.openLords);
        openLords.setOnClickListener(v -> showLords());

        openNameAge = findViewById(R.id.openNameAge);
        openNameAge.setOnClickListener(v -> showNameAge());
    }

    private void showAuthor() {
        Intent intent = new Intent(this, AuthorActivity.class);
        startActivity(intent);
    }

    private void showPassword() {
        Intent intent = new Intent(this, PasswordMainActivity.class);
        startActivity(intent);
    }

    private void showLords() {
        Intent intent = new Intent(this, LordsMainActivity.class);
        startActivity(intent);
    }

    private void showNameAge() {
        Intent intent = new Intent(this, NameAgeMainActivity.class);
        startActivity(intent);
    }

}