package main;

import java.io.IOException;

import udp.Client;

public class ClientRunner {

	public static void main(String[] args) {
		try {
			Client prg = new Client();
			prg.init("localhost", ServerRunner.PORT);
			prg.runClient();
		} catch (IOException ex) {
			ex.printStackTrace();
			System.out.println("Error recibiendo o enviando petición.");
		}
	}
}
