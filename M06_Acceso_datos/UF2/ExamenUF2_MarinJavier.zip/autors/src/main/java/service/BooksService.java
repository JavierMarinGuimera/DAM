package service;

import pojos.Llibres;

public interface BooksService {
    public Llibres readOne(int id);
}
