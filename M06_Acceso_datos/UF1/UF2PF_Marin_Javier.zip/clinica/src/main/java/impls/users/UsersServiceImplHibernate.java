package impls.users;

import java.util.List;

import pojos.Usuaris;
import services.UsersService;

public class UsersServiceImplHibernate implements UsersService {

    @Override
    public List<Usuaris> readAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean createOne(Usuaris user) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Usuaris readOne(String user_id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean updateOne(Usuaris user) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean deleteOne(String user_id) {
        // TODO Auto-generated method stub
        return false;
    }

}
