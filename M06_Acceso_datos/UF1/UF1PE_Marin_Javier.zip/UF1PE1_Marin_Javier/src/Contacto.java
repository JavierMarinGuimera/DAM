

public class Contacto {

}
