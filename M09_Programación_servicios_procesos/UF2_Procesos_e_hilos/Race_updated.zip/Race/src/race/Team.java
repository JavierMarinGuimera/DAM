package race;

public class Team {

}
