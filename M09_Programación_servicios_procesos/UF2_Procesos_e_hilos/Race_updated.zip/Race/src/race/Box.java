package race;

public class Box {

}
